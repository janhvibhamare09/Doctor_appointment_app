package com.example.doctorappointmentbookingapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class EditProfileActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val preferences = getSharedPreferences(
            "patient_profile",
            MODE_PRIVATE
        )

        val savedName = preferences.getString(
            "name",
            "John Doe"
        ) ?: "John Doe"

        val savedEmail = preferences.getString(
            "email",
            "johndoe@gmail.com"
        ) ?: "johndoe@gmail.com"

        val savedPhone = preferences.getString(
            "phone",
            "+91 98765 43210"
        ) ?: "+91 98765 43210"

        setContent {

            EditProfileScreen(
                initialName = savedName,
                initialEmail = savedEmail,
                initialPhone = savedPhone,

                onBack = {
                    finish()
                },

                onSave = { name, email, phone ->

                    preferences.edit()
                        .putString("name", name)
                        .putString("email", email)
                        .putString("phone", phone)
                        .apply()
                }
            )
        }
    }
}

@Composable
fun EditProfileScreen(
    initialName: String,
    initialEmail: String,
    initialPhone: String,
    onBack: () -> Unit,
    onSave: (String, String, String) -> Unit
) {

    var name by remember {
        mutableStateOf(initialName)
    }

    var email by remember {
        mutableStateOf(initialEmail)
    }

    var phone by remember {
        mutableStateOf(initialPhone)
    }

    var showSavedMessage by remember {
        mutableStateOf(false)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF7F9FC))
            .padding(20.dp)
    ) {

        Row(
            verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
        ) {

            IconButton(
                onClick = onBack
            ) {

                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back"
                )
            }

            Text(
                text = "Edit Profile",
                fontSize = 23.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(
            modifier = Modifier.height(25.dp)
        )

        Text(
            text = "Full Name",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(
            modifier = Modifier.height(8.dp)
        )

        OutlinedTextField(
            value = name,
            onValueChange = {
                name = it
            },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(
            modifier = Modifier.height(18.dp)
        )

        Text(
            text = "Email",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(
            modifier = Modifier.height(8.dp)
        )

        OutlinedTextField(
            value = email,
            onValueChange = {
                email = it
            },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(
            modifier = Modifier.height(18.dp)
        )

        Text(
            text = "Phone Number",
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(
            modifier = Modifier.height(8.dp)
        )

        OutlinedTextField(
            value = phone,
            onValueChange = {
                phone = it
            },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(
            modifier = Modifier.height(30.dp)
        )

        Button(
            onClick = {

                onSave(
                    name,
                    email,
                    phone
                )

                showSavedMessage = true
            },

            modifier = Modifier
                .fillMaxWidth()
                .height(55.dp),

            shape = RoundedCornerShape(15.dp)
        ) {

            Text(
                text = "Save Changes",
                fontSize = 17.sp
            )
        }

        if (showSavedMessage) {

            Spacer(
                modifier = Modifier.height(20.dp)
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(15.dp)
            ) {

                Text(
                    text = "Profile saved successfully! ✅",

                    modifier = Modifier.padding(18.dp),

                    fontSize = 15.sp,

                    color = Color(0xFF2E7D32),

                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}