package com.example.doctorappointmentbookingapp

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {

            var showLogin by remember {
                mutableStateOf(false)
            }

            var showDoctorDashboard by remember {
                mutableStateOf(false)
            }

            var showDoctorProfile by remember {
                mutableStateOf(false)
            }

            var doctorName by remember {
                mutableStateOf("Dr. Sarah Johnson")
            }

            when {

                showDoctorProfile -> {

                    val preferences =
                        getSharedPreferences(
                            "doctor_profile",
                            MODE_PRIVATE
                        )

                    val savedName =
                        preferences.getString(
                            "name",
                            "Dr. Sarah Johnson"
                        ) ?: "Dr. Sarah Johnson"

                    val savedSpeciality =
                        preferences.getString(
                            "speciality",
                            "Cardiologist"
                        ) ?: "Cardiologist"

                    val savedExperience =
                        preferences.getString(
                            "experience",
                            "10 years"
                        ) ?: "10 years"

                    val savedClinic =
                        preferences.getString(
                            "clinic",
                            "City Heart Clinic"
                        ) ?: "City Heart Clinic"

                    DoctorProfileManagementScreen(
                        initialName = savedName,
                        initialSpeciality = savedSpeciality,
                        initialExperience = savedExperience,
                        initialClinic = savedClinic,

                        onBack = {
                            showDoctorProfile = false
                        },

                        onSave = {
                                name,
                                speciality,
                                experience,
                                clinic ->

                            preferences.edit()
                                .putString("name", name)
                                .putString(
                                    "speciality",
                                    speciality
                                )
                                .putString(
                                    "experience",
                                    experience
                                )
                                .putString(
                                    "clinic",
                                    clinic
                                )
                                .apply()

                            doctorName = name
                        }
                    )
                }

                showDoctorDashboard -> {

                    DoctorDashboardScreen(
                        doctorName = doctorName,

                        onProfileClick = {

                            showDoctorProfile = true
                        }
                    )
                }

                showLogin -> {

                    LoginScreen(

                        onPatientLogin = {

                            val intent = Intent(
                                this@MainActivity,
                                HomeActivity::class.java
                            )

                            startActivity(intent)
                        },

                        onDoctorLogin = {

                            val preferences =
                                getSharedPreferences(
                                    "doctor_profile",
                                    MODE_PRIVATE
                                )

                            doctorName =
                                preferences.getString(
                                    "name",
                                    "Dr. Sarah Johnson"
                                )
                                    ?: "Dr. Sarah Johnson"

                            showDoctorDashboard = true
                        }
                    )
                }

                else -> {

                    SplashScreen()
                }
            }

            if (!showLogin &&
                !showDoctorDashboard &&
                !showDoctorProfile
            ) {

                LaunchedEffect(Unit) {

                    delay(2000)

                    showLogin = true
                }
            }
        }
    }
}

@Composable
fun SplashScreen() {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Color(0xFFF7F9FC)
            ),

        horizontalAlignment =
            Alignment.CenterHorizontally,

        verticalArrangement =
            Arrangement.Center
    ) {

        Text(
            text = "❤️",
            fontSize = 60.sp
        )

        Spacer(
            modifier = Modifier.height(20.dp)
        )

        Text(
            text =
                "Doctor Appointment Booking App",

            fontSize = 24.sp,

            fontWeight =
                FontWeight.Bold
        )

        Spacer(
            modifier = Modifier.height(10.dp)
        )

        Text(
            text =
                "Your Health, Our Priority",

            fontSize = 15.sp,

            color = Color.Gray
        )
    }
}