package com.example.doctorappointmentbookingapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class BookingActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {

            BookingScreen(

                onBack = {
                    finish()
                },

                onSaveAppointment = { date, time ->

                    val preferences = getSharedPreferences(
                        "appointments",
                        MODE_PRIVATE
                    )

                    preferences.edit()
                        .putString(
                            "doctor",
                            "Dr. Sarah Johnson"
                        )
                        .putString(
                            "speciality",
                            "Cardiologist"
                        )
                        .putString(
                            "date",
                            date
                        )
                        .putString(
                            "time",
                            time
                        )
                        .putBoolean(
                            "booked",
                            true
                        )
                        .apply()
                }
            )
        }
    }
}

@Composable
fun BookingScreen(
    onBack: () -> Unit,
    onSaveAppointment: (String, String) -> Unit
) {

    var selectedDate by remember {
        mutableStateOf("")
    }

    var selectedTime by remember {
        mutableStateOf("")
    }

    var showConfirmation by remember {
        mutableStateOf(false)
    }

    val dates = listOf(
        "20 Sep",
        "21 Sep",
        "22 Sep",
        "23 Sep",
        "24 Sep"
    )

    val times = listOf(
        "10:00 AM",
        "11:00 AM",
        "2:00 PM",
        "4:00 PM",
        "6:00 PM"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Color(0xFFF7F9FC)
            )
    ) {

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {

            IconButton(
                onClick = onBack
            ) {

                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back"
                )
            }

            Text(
                text = "Book Appointment",
                fontSize = 23.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(
                    rememberScrollState()
                )
                .padding(
                    horizontal = 20.dp
                )
        ) {

            Text(
                text = "Doctor",
                fontSize = 16.sp,
                color = Color.Gray
            )

            Spacer(
                modifier = Modifier.height(5.dp)
            )

            Text(
                text = "Dr. Sarah Johnson",
                fontSize = 21.sp,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = "Cardiologist",
                fontSize = 15.sp,
                color = Color(0xFF1976D2)
            )

            Spacer(
                modifier = Modifier.height(25.dp)
            )

            Text(
                text = "Choose Date",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(
                modifier = Modifier.height(10.dp)
            )

            dates.forEach { date ->

                Button(
                    onClick = {
                        selectedDate = date
                    },

                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(
                            vertical = 3.dp
                        ),

                    colors = ButtonDefaults.buttonColors(

                        containerColor =
                            if (selectedDate == date)
                                Color(0xFF1976D2)
                            else
                                Color.White,

                        contentColor =
                            if (selectedDate == date)
                                Color.White
                            else
                                Color.DarkGray
                    ),

                    shape = RoundedCornerShape(12.dp)
                ) {

                    Icon(
                        imageVector =
                            Icons.Default.CalendarMonth,

                        contentDescription =
                            "Date"
                    )

                    Spacer(
                        modifier = Modifier.width(10.dp)
                    )

                    Text(
                        text = date
                    )
                }
            }

            Spacer(
                modifier = Modifier.height(20.dp)
            )

            Text(
                text = "Choose Time",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(
                modifier = Modifier.height(10.dp)
            )

            times.forEach { time ->

                Button(
                    onClick = {
                        selectedTime = time
                    },

                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(
                            vertical = 3.dp
                        ),

                    colors = ButtonDefaults.buttonColors(

                        containerColor =
                            if (selectedTime == time)
                                Color(0xFF1976D2)
                            else
                                Color.White,

                        contentColor =
                            if (selectedTime == time)
                                Color.White
                            else
                                Color.DarkGray
                    ),

                    shape = RoundedCornerShape(12.dp)
                ) {

                    Icon(
                        imageVector =
                            Icons.Default.Schedule,

                        contentDescription =
                            "Time"
                    )

                    Spacer(
                        modifier = Modifier.width(10.dp)
                    )

                    Text(
                        text = time
                    )
                }
            }

            Spacer(
                modifier = Modifier.height(20.dp)
            )

            Button(
                onClick = {

                    if (
                        selectedDate.isNotEmpty() &&
                        selectedTime.isNotEmpty()
                    ) {

                        showConfirmation = true
                    }
                },

                modifier = Modifier
                    .fillMaxWidth()
                    .height(55.dp),

                shape = RoundedCornerShape(15.dp)
            ) {

                Text(
                    text = "Confirm Appointment",
                    fontSize = 17.sp
                )
            }

            Spacer(
                modifier = Modifier.height(30.dp)
            )
        }
    }

    if (showConfirmation) {

        AlertDialog(

            onDismissRequest = {

                showConfirmation = false
            },

            title = {

                Text(
                    text =
                        "Appointment Confirmed! 🎉",

                    fontWeight =
                        FontWeight.Bold
                )
            },

            text = {

                Column {

                    Text(
                        text =
                            "Doctor: Dr. Sarah Johnson"
                    )

                    Spacer(
                        modifier =
                            Modifier.height(8.dp)
                    )

                    Text(
                        text =
                            "Speciality: Cardiologist"
                    )

                    Spacer(
                        modifier =
                            Modifier.height(8.dp)
                    )

                    Text(
                        text =
                            "Date: $selectedDate"
                    )

                    Spacer(
                        modifier =
                            Modifier.height(8.dp)
                    )

                    Text(
                        text =
                            "Time: $selectedTime"
                    )
                }
            },

            confirmButton = {

                Button(
                    onClick = {

                        onSaveAppointment(
                            selectedDate,
                            selectedTime
                        )

                        showConfirmation = false

                        onBack()
                    }
                ) {

                    Text(
                        text = "Done"
                    )
                }
            }
        )
    }
}