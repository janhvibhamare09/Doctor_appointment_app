package com.example.doctorappointmentbookingapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class DoctorProfileManagementActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val preferences = getSharedPreferences(
            "doctor_profile",
            MODE_PRIVATE
        )

        val savedName = preferences.getString(
            "name",
            "Dr. Sarah Johnson"
        ) ?: "Dr. Sarah Johnson"

        val savedSpeciality = preferences.getString(
            "speciality",
            "Cardiologist"
        ) ?: "Cardiologist"

        val savedExperience = preferences.getString(
            "experience",
            "10 years"
        ) ?: "10 years"

        val savedClinic = preferences.getString(
            "clinic",
            "City Heart Clinic"
        ) ?: "City Heart Clinic"

        setContent {

            DoctorProfileManagementScreen(
                initialName = savedName,
                initialSpeciality = savedSpeciality,
                initialExperience = savedExperience,
                initialClinic = savedClinic,

                onBack = {
                    finish()
                },

                onSave = { name, speciality, experience, clinic ->

                    preferences.edit()
                        .putString("name", name)
                        .putString("speciality", speciality)
                        .putString("experience", experience)
                        .putString("clinic", clinic)
                        .apply()
                }
            )
        }
    }
}

@Composable
fun DoctorProfileManagementScreen(
    initialName: String,
    initialSpeciality: String,
    initialExperience: String,
    initialClinic: String,
    onBack: () -> Unit,
    onSave: (
        String,
        String,
        String,
        String
    ) -> Unit
) {

    var doctorName by remember {
        mutableStateOf(initialName)
    }

    var speciality by remember {
        mutableStateOf(initialSpeciality)
    }

    var experience by remember {
        mutableStateOf(initialExperience)
    }

    var clinic by remember {
        mutableStateOf(initialClinic)
    }

    var saved by remember {
        mutableStateOf(false)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF7F9FC))
            .padding(20.dp)
    ) {

        Row(
            verticalAlignment =
                Alignment.CenterVertically
        ) {

            IconButton(
                onClick = onBack
            ) {

                Icon(
                    imageVector =
                        Icons.Default.ArrowBack,

                    contentDescription =
                        "Back"
                )
            }

            Text(
                text = "Doctor Profile",
                fontSize = 23.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(
            modifier = Modifier.height(25.dp)
        )

        Box(
            modifier = Modifier
                .size(90.dp)
                .align(
                    Alignment.CenterHorizontally
                )
                .background(
                    Color(0xFFE3F2FD),
                    RoundedCornerShape(20.dp)
                ),

            contentAlignment =
                Alignment.Center
        ) {

            Icon(
                imageVector =
                    Icons.Default.Person,

                contentDescription =
                    "Doctor",

                modifier =
                    Modifier.size(50.dp),

                tint =
                    Color(0xFF1976D2)
            )
        }

        Spacer(
            modifier = Modifier.height(20.dp)
        )

        OutlinedTextField(
            value = doctorName,

            onValueChange = {
                doctorName = it
                saved = false
            },

            modifier =
                Modifier.fillMaxWidth(),

            label = {
                Text("Doctor Name")
            },

            singleLine = true,

            shape =
                RoundedCornerShape(12.dp)
        )

        Spacer(
            modifier = Modifier.height(15.dp)
        )

        OutlinedTextField(
            value = speciality,

            onValueChange = {
                speciality = it
                saved = false
            },

            modifier =
                Modifier.fillMaxWidth(),

            label = {
                Text("Speciality")
            },

            singleLine = true,

            shape =
                RoundedCornerShape(12.dp)
        )

        Spacer(
            modifier = Modifier.height(15.dp)
        )

        OutlinedTextField(
            value = experience,

            onValueChange = {
                experience = it
                saved = false
            },

            modifier =
                Modifier.fillMaxWidth(),

            label = {
                Text("Experience")
            },

            singleLine = true,

            shape =
                RoundedCornerShape(12.dp)
        )

        Spacer(
            modifier = Modifier.height(15.dp)
        )

        OutlinedTextField(
            value = clinic,

            onValueChange = {
                clinic = it
                saved = false
            },

            modifier =
                Modifier.fillMaxWidth(),

            label = {
                Text("Clinic Name")
            },

            singleLine = true,

            shape =
                RoundedCornerShape(12.dp)
        )

        Spacer(
            modifier = Modifier.height(25.dp)
        )

        Button(
            onClick = {

                onSave(
                    doctorName,
                    speciality,
                    experience,
                    clinic
                )

                saved = true
            },

            modifier = Modifier
                .fillMaxWidth()
                .height(55.dp),

            shape =
                RoundedCornerShape(15.dp)
        ) {

            Text(
                text = "Save Profile",
                fontSize = 17.sp
            )
        }

        if (saved) {

            Spacer(
                modifier = Modifier.height(15.dp)
            )

            Text(
                text =
                    "Doctor profile saved successfully! ✅",

                color =
                    Color(0xFF2E7D32),

                fontWeight =
                    FontWeight.Bold,

                fontSize =
                    15.sp
            )
        }
    }
}