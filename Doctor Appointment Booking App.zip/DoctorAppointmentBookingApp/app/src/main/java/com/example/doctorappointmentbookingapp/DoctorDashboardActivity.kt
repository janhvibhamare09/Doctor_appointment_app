package com.example.doctorappointmentbookingapp

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class DoctorDashboardActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {

            DoctorDashboardScreen(
                doctorName = "Doctor",

                onProfileClick = {

                    val intent = Intent(
                        this@DoctorDashboardActivity,
                        DoctorProfileManagementActivity::class.java
                    )

                    startActivity(intent)
                }
            )
        }
    }
}

@Composable
fun DoctorDashboardScreen(
    doctorName: String,
    onProfileClick: () -> Unit
) {

    var appointment1Status by remember {
        mutableStateOf("Pending")
    }

    var appointment2Status by remember {
        mutableStateOf("Pending")
    }

    var appointment3Status by remember {
        mutableStateOf("Pending")
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF7F9FC))
            .padding(20.dp)
    ) {

        Text(
            text = "Doctor Dashboard",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(
            modifier = Modifier.height(6.dp)
        )

        Text(
            text = "Welcome, $doctorName 👋",
            fontSize = 16.sp,
            color = Color.Gray
        )

        Spacer(
            modifier = Modifier.height(20.dp)
        )

        Button(
            onClick = onProfileClick,

            modifier = Modifier
                .fillMaxWidth()
                .height(55.dp),

            shape = RoundedCornerShape(15.dp)
        ) {

            Icon(
                imageVector = Icons.Default.Person,
                contentDescription = "Profile"
            )

            Spacer(
                modifier = Modifier.width(8.dp)
            )

            Text(
                text = "Manage Doctor Profile",
                fontSize = 16.sp
            )
        }

        Spacer(
            modifier = Modifier.height(25.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            DashboardCard(
                title = "Appointments",
                value = "12",
                icon = Icons.Default.CalendarMonth,
                modifier = Modifier.weight(1f)
            )

            DashboardCard(
                title = "Patients",
                value = "48",
                icon = Icons.Default.Person,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(
            modifier = Modifier.height(15.dp)
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            DashboardCard(
                title = "Today",
                value = "5",
                icon = Icons.Default.Schedule,
                modifier = Modifier.weight(1f)
            )

            DashboardCard(
                title = "Completed",
                value = "32",
                icon = Icons.Default.CheckCircle,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(
            modifier = Modifier.height(30.dp)
        )

        Text(
            text = "Today's Appointments",
            fontSize = 21.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(
            modifier = Modifier.height(15.dp)
        )

        DoctorAppointmentCard(
            patientName = "John Doe",
            time = "10:00 AM",
            status = appointment1Status,

            onAccept = {
                appointment1Status = "Accepted"
            },

            onReject = {
                appointment1Status = "Rejected"
            }
        )

        Spacer(
            modifier = Modifier.height(12.dp)
        )

        DoctorAppointmentCard(
            patientName = "Emily Smith",
            time = "11:00 AM",
            status = appointment2Status,

            onAccept = {
                appointment2Status = "Accepted"
            },

            onReject = {
                appointment2Status = "Rejected"
            }
        )

        Spacer(
            modifier = Modifier.height(12.dp)
        )

        DoctorAppointmentCard(
            patientName = "Michael Brown",
            time = "2:00 PM",
            status = appointment3Status,

            onAccept = {
                appointment3Status = "Accepted"
            },

            onReject = {
                appointment3Status = "Rejected"
            }
        )
    }
}

@Composable
fun DashboardCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier
) {

    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 3.dp
        )
    ) {

        Column(
            modifier = Modifier.padding(16.dp)
        ) {

            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = Color(0xFF1976D2),
                modifier = Modifier.size(30.dp)
            )

            Spacer(
                modifier = Modifier.height(10.dp)
            )

            Text(
                text = value,
                fontSize = 25.sp,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = title,
                fontSize = 13.sp,
                color = Color.Gray
            )
        }
    }
}

@Composable
fun DoctorAppointmentCard(
    patientName: String,
    time: String,
    status: String,
    onAccept: () -> Unit,
    onReject: () -> Unit
) {

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp)
    ) {

        Column(
            modifier = Modifier.padding(16.dp)
        ) {

            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {

                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .background(
                            Color(0xFFE3F2FD),
                            RoundedCornerShape(12.dp)
                        ),

                    contentAlignment = Alignment.Center
                ) {

                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "Patient",
                        tint = Color(0xFF1976D2)
                    )
                }

                Spacer(
                    modifier = Modifier.width(15.dp)
                )

                Column(
                    modifier = Modifier.weight(1f)
                ) {

                    Text(
                        text = patientName,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(
                        modifier = Modifier.height(4.dp)
                    )

                    Text(
                        text = time,
                        fontSize = 13.sp,
                        color = Color.Gray
                    )
                }

                Text(
                    text = status,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,

                    color = when (status) {
                        "Accepted" -> Color(0xFF2E7D32)
                        "Rejected" -> Color(0xFFC62828)
                        else -> Color(0xFFEF6C00)
                    }
                )
            }

            if (status == "Pending") {

                Spacer(
                    modifier = Modifier.height(12.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement =
                        Arrangement.spacedBy(10.dp)
                ) {

                    Button(
                        onClick = onAccept,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {

                        Icon(
                            imageVector =
                                Icons.Default.CheckCircle,
                            contentDescription = "Accept"
                        )

                        Spacer(
                            modifier = Modifier.width(5.dp)
                        )

                        Text("Accept")
                    }

                    OutlinedButton(
                        onClick = onReject,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {

                        Icon(
                            imageVector =
                                Icons.Default.Close,
                            contentDescription = "Reject"
                        )

                        Spacer(
                            modifier = Modifier.width(5.dp)
                        )

                        Text("Reject")
                    }
                }
            }
        }
    }
}