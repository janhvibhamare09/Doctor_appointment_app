package com.example.doctorappointmentbookingapp

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class ProfileActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val preferences = getSharedPreferences(
            "patient_profile",
            MODE_PRIVATE
        )

        val name = preferences.getString(
            "name",
            "John Doe"
        ) ?: "John Doe"

        val email = preferences.getString(
            "email",
            "johndoe@gmail.com"
        ) ?: "johndoe@gmail.com"

        val phone = preferences.getString(
            "phone",
            "+91 98765 43210"
        ) ?: "+91 98765 43210"

        setContent {

            ProfileScreen(
                name = name,
                email = email,
                phone = phone,

                onBack = {
                    finish()
                },

                onEditProfile = {

                    val intent = Intent(
                        this,
                        EditProfileActivity::class.java
                    )

                    startActivity(intent)
                }
            )
        }
    }
}

@Composable
fun ProfileScreen(
    name: String,
    email: String,
    phone: String,
    onBack: () -> Unit,
    onEditProfile: () -> Unit
) {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Color(0xFFF7F9FC)
            )
            .padding(20.dp)
    ) {

        Row(
            verticalAlignment =
                Alignment.CenterVertically
        ) {

            IconButton(
                onClick = onBack
            ) {

                Icon(
                    imageVector =
                        Icons.Default.ArrowBack,

                    contentDescription =
                        "Back"
                )
            }

            Text(
                text = "My Profile",
                fontSize = 23.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(
            modifier = Modifier.height(30.dp)
        )

        Box(
            modifier = Modifier
                .size(110.dp)
                .align(
                    Alignment.CenterHorizontally
                )
                .background(
                    color = Color(0xFFE3F2FD),
                    shape = CircleShape
                ),

            contentAlignment =
                Alignment.Center
        ) {

            Icon(
                imageVector =
                    Icons.Default.Person,

                contentDescription =
                    "Profile",

                modifier =
                    Modifier.size(60.dp),

                tint =
                    Color(0xFF1976D2)
            )
        }

        Spacer(
            modifier = Modifier.height(15.dp)
        )

        Text(
            text = name,
            fontSize = 25.sp,
            fontWeight = FontWeight.Bold,

            modifier =
                Modifier.align(
                    Alignment.CenterHorizontally
                )
        )

        Text(
            text = "Patient",
            fontSize = 15.sp,
            color = Color(0xFF1976D2),

            modifier =
                Modifier.align(
                    Alignment.CenterHorizontally
                )
        )

        Spacer(
            modifier = Modifier.height(30.dp)
        )

        Card(
            modifier =
                Modifier.fillMaxWidth(),

            shape =
                RoundedCornerShape(18.dp),

            elevation =
                CardDefaults.cardElevation(
                    defaultElevation = 4.dp
                )
        ) {

            Column(
                modifier =
                    Modifier.padding(20.dp)
            ) {

                Text(
                    text =
                        "Personal Information",

                    fontSize = 19.sp,

                    fontWeight =
                        FontWeight.Bold
                )

                Spacer(
                    modifier =
                        Modifier.height(20.dp)
                )

                Row(
                    verticalAlignment =
                        Alignment.CenterVertically
                ) {

                    Icon(
                        imageVector =
                            Icons.Default.Email,

                        contentDescription =
                            "Email",

                        tint =
                            Color(0xFF1976D2)
                    )

                    Spacer(
                        modifier =
                            Modifier.width(15.dp)
                    )

                    Column {

                        Text(
                            text = "Email",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )

                        Text(
                            text = email,
                            fontSize = 15.sp
                        )
                    }
                }

                Spacer(
                    modifier =
                        Modifier.height(18.dp)
                )

                Row(
                    verticalAlignment =
                        Alignment.CenterVertically
                ) {

                    Icon(
                        imageVector =
                            Icons.Default.Phone,

                        contentDescription =
                            "Phone",

                        tint =
                            Color(0xFF1976D2)
                    )

                    Spacer(
                        modifier =
                            Modifier.width(15.dp)
                    )

                    Column {

                        Text(
                            text = "Phone",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )

                        Text(
                            text = phone,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        }

        Spacer(
            modifier =
                Modifier.height(25.dp)
        )

        Button(
            onClick = onEditProfile,

            modifier = Modifier
                .fillMaxWidth()
                .height(55.dp),

            shape =
                RoundedCornerShape(15.dp)
        ) {

            Text(
                text = "Edit Profile",
                fontSize = 17.sp
            )
        }
    }
}