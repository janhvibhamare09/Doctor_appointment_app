package com.example.doctorappointmentbookingapp

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class HomeActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            DoctorAppointmentHome()
        }
    }
}

data class Doctor(
    val name: String,
    val speciality: String,
    val experience: String
)

@Composable
fun DoctorAppointmentHome() {

    var selectedCategory by remember {
        mutableStateOf("All")
    }

    var searchText by remember {
        mutableStateOf("")
    }

    var favoriteDoctors by remember {
        mutableStateOf(setOf<String>())
    }

    val context = LocalContext.current

    val categories = listOf(
        "All",
        "Dentist",
        "Cardiologist",
        "Dermatologist",
        "Neurologist"
    )

    val doctors = listOf(
        Doctor(
            "Dr. Sarah Johnson",
            "Cardiologist",
            "10 years experience"
        ),
        Doctor(
            "Dr. Michael Smith",
            "Dentist",
            "8 years experience"
        ),
        Doctor(
            "Dr. Emily Brown",
            "Dermatologist",
            "7 years experience"
        )
    )

    val filteredDoctors = doctors.filter { doctor ->

        val matchesSearch =
            doctor.name.contains(
                searchText,
                ignoreCase = true
            ) ||
                    doctor.speciality.contains(
                        searchText,
                        ignoreCase = true
                    )

        val matchesCategory =
            selectedCategory == "All" ||
                    doctor.speciality == selectedCategory

        matchesSearch && matchesCategory
    }

    Scaffold(

        bottomBar = {

            NavigationBar {

                NavigationBarItem(
                    selected = true,
                    onClick = {},
                    icon = {
                        Icon(
                            Icons.Default.Home,
                            contentDescription = "Home"
                        )
                    },
                    label = {
                        Text("Home")
                    }
                )

                NavigationBarItem(
                    selected = false,
                    onClick = {

                        val intent = Intent(
                            context,
                            AppointmentsActivity::class.java
                        )

                        context.startActivity(intent)
                    },
                    icon = {
                        Icon(
                            Icons.Default.CalendarMonth,
                            contentDescription = "Appointments"
                        )
                    },
                    label = {
                        Text("Appointments")
                    }
                )

                NavigationBarItem(
                    selected = false,
                    onClick = {

                        val intent = Intent(
                            context,
                            FavoritesActivity::class.java
                        )

                        context.startActivity(intent)
                    },
                    icon = {
                        Icon(
                            Icons.Default.Favorite,
                            contentDescription = "Favorites"
                        )
                    },
                    label = {
                        Text("Favorites")
                    }
                )

                NavigationBarItem(
                    selected = false,
                    onClick = {

                        val intent = Intent(
                            context,
                            ProfileActivity::class.java
                        )

                        context.startActivity(intent)
                    },
                    icon = {
                        Icon(
                            Icons.Default.Person,
                            contentDescription = "Profile"
                        )
                    },
                    label = {
                        Text("Profile")
                    }
                )
            }
        }

    ) { paddingValues ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF7F9FC))
                .padding(paddingValues)
                .padding(20.dp)
        ) {

            Text(
                text = "Hello 👋",
                fontSize = 18.sp,
                color = Color.Gray
            )

            Spacer(
                modifier = Modifier.height(4.dp)
            )

            Text(
                text = "Find Your Doctor",
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(
                modifier = Modifier.height(20.dp)
            )

            OutlinedTextField(
                value = searchText,
                onValueChange = {
                    searchText = it
                },
                modifier = Modifier.fillMaxWidth(),
                placeholder = {
                    Text("Search doctors...")
                },
                leadingIcon = {
                    Icon(
                        Icons.Default.Search,
                        contentDescription = "Search"
                    )
                },
                shape = RoundedCornerShape(14.dp),
                singleLine = true
            )

            Spacer(
                modifier = Modifier.height(24.dp)
            )

            Text(
                text = "Specialities",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(
                modifier = Modifier.height(12.dp)
            )

            LazyRow(
                horizontalArrangement =
                    Arrangement.spacedBy(10.dp)
            ) {

                items(categories) { category ->

                    Button(
                        onClick = {
                            selectedCategory = category
                        },
                        colors = ButtonDefaults.buttonColors(

                            containerColor =
                                if (selectedCategory == category)
                                    Color(0xFF1976D2)
                                else
                                    Color.White,

                            contentColor =
                                if (selectedCategory == category)
                                    Color.White
                                else
                                    Color.DarkGray
                        ),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Text(category)
                    }
                }
            }

            Spacer(
                modifier = Modifier.height(28.dp)
            )

            Text(
                text = "Popular Doctors",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(
                modifier = Modifier.height(14.dp)
            )

            if (filteredDoctors.isEmpty()) {

                Text(
                    text = "No doctors found",
                    fontSize = 16.sp,
                    color = Color.Gray
                )

            } else {

                filteredDoctors.forEach { doctor ->

                    DoctorCard(
                        name = doctor.name,
                        speciality = doctor.speciality,
                        experience = doctor.experience,
                        isFavorite =
                            favoriteDoctors.contains(
                                doctor.name
                            ),
                        onFavoriteClick = {

                            favoriteDoctors =
                                if (
                                    favoriteDoctors.contains(
                                        doctor.name
                                    )
                                ) {
                                    favoriteDoctors -
                                            doctor.name
                                } else {
                                    favoriteDoctors +
                                            doctor.name
                                }
                        },
                        onClick = {

                            val intent = Intent(
                                context,
                                DoctorProfileActivity::class.java
                            )

                            context.startActivity(intent)
                        }
                    )

                    Spacer(
                        modifier = Modifier.height(14.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun DoctorCard(
    name: String,
    speciality: String,
    experience: String,
    isFavorite: Boolean,
    onFavoriteClick: () -> Unit,
    onClick: () -> Unit
) {

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable {
                onClick()
            },
        shape = RoundedCornerShape(18.dp),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 4.dp
        )
    ) {

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment =
                Alignment.CenterVertically
        ) {

            Box(
                modifier = Modifier
                    .size(65.dp)
                    .clip(
                        RoundedCornerShape(15.dp)
                    )
                    .background(
                        Color(0xFFE3F2FD)
                    ),
                contentAlignment =
                    Alignment.Center
            ) {

                Icon(
                    Icons.Default.Person,
                    contentDescription = "Doctor",
                    modifier = Modifier.size(35.dp),
                    tint = Color(0xFF1976D2)
                )
            }

            Spacer(
                modifier = Modifier.width(15.dp)
            )

            Column(
                modifier = Modifier.weight(1f)
            ) {

                Text(
                    text = name,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(
                    modifier = Modifier.height(4.dp)
                )

                Text(
                    text = speciality,
                    fontSize = 14.sp,
                    color = Color(0xFF1976D2)
                )

                Spacer(
                    modifier = Modifier.height(4.dp)
                )

                Text(
                    text = experience,
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }

            IconButton(
                onClick = {
                    onFavoriteClick()
                }
            ) {

                Icon(
                    Icons.Default.Favorite,
                    contentDescription = "Favorite",
                    tint =
                        if (isFavorite)
                            Color.Red
                        else
                            Color.Gray
                )
            }
        }
    }
}