package com.example.doctorappointmentbookingapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class AppointmentsActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val preferences = getSharedPreferences(
            "appointments",
            MODE_PRIVATE
        )

        val booked = preferences.getBoolean(
            "booked",
            false
        )

        val doctor = preferences.getString(
            "doctor",
            ""
        ) ?: ""

        val speciality = preferences.getString(
            "speciality",
            ""
        ) ?: ""

        val date = preferences.getString(
            "date",
            ""
        ) ?: ""

        val time = preferences.getString(
            "time",
            ""
        ) ?: ""

        setContent {

            AppointmentsScreen(
                booked = booked,
                doctor = doctor,
                speciality = speciality,
                date = date,
                time = time,
                onBack = {
                    finish()
                }
            )
        }
    }
}

@Composable
fun AppointmentsScreen(
    booked: Boolean,
    doctor: String,
    speciality: String,
    date: String,
    time: String,
    onBack: () -> Unit
) {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Color(0xFFF7F9FC)
            )
            .padding(20.dp)
    ) {

        Row(
            verticalAlignment =
                Alignment.CenterVertically
        ) {

            IconButton(
                onClick = onBack
            ) {

                Icon(
                    imageVector =
                        Icons.Default.ArrowBack,

                    contentDescription =
                        "Back"
                )
            }

            Text(
                text = "My Appointments",
                fontSize = 23.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(
            modifier = Modifier.height(25.dp)
        )

        if (!booked) {

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp)
            ) {

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(30.dp),

                    horizontalAlignment =
                        Alignment.CenterHorizontally
                ) {

                    Icon(
                        imageVector =
                            Icons.Default.CalendarMonth,

                        contentDescription =
                            "No Appointments",

                        modifier =
                            Modifier.size(60.dp),

                        tint =
                            Color(0xFF1976D2)
                    )

                    Spacer(
                        modifier =
                            Modifier.height(15.dp)
                    )

                    Text(
                        text =
                            "No appointments yet",

                        fontSize = 18.sp,

                        fontWeight =
                            FontWeight.Bold
                    )

                    Spacer(
                        modifier =
                            Modifier.height(8.dp)
                    )

                    Text(
                        text =
                            "Book an appointment with a doctor to see it here.",

                        fontSize = 14.sp,

                        color = Color.Gray
                    )
                }
            }

        } else {

            Card(
                modifier =
                    Modifier.fillMaxWidth(),

                shape =
                    RoundedCornerShape(18.dp),

                elevation =
                    CardDefaults.cardElevation(
                        defaultElevation = 4.dp
                    )
            ) {

                Column(
                    modifier =
                        Modifier.padding(20.dp)
                ) {

                    Row(
                        verticalAlignment =
                            Alignment.CenterVertically
                    ) {

                        Box(
                            modifier =
                                Modifier
                                    .size(65.dp)
                                    .background(
                                        Color(0xFFE3F2FD),
                                        RoundedCornerShape(15.dp)
                                    ),

                            contentAlignment =
                                Alignment.Center
                        ) {

                            Icon(
                                imageVector =
                                    Icons.Default.Person,

                                contentDescription =
                                    "Doctor",

                                modifier =
                                    Modifier.size(35.dp),

                                tint =
                                    Color(0xFF1976D2)
                            )
                        }

                        Spacer(
                            modifier =
                                Modifier.width(15.dp)
                        )

                        Column {

                            Text(
                                text = doctor,
                                fontSize = 18.sp,
                                fontWeight =
                                    FontWeight.Bold
                            )

                            Spacer(
                                modifier =
                                    Modifier.height(4.dp)
                            )

                            Text(
                                text = speciality,
                                fontSize = 14.sp,
                                color =
                                    Color(0xFF1976D2)
                            )
                        }
                    }

                    Spacer(
                        modifier =
                            Modifier.height(20.dp)
                    )

                    HorizontalDivider()

                    Spacer(
                        modifier =
                            Modifier.height(15.dp)
                    )

                    Row(
                        verticalAlignment =
                            Alignment.CenterVertically
                    ) {

                        Icon(
                            imageVector =
                                Icons.Default.CalendarMonth,

                            contentDescription =
                                "Date",

                            tint =
                                Color(0xFF1976D2)
                        )

                        Spacer(
                            modifier =
                                Modifier.width(10.dp)
                        )

                        Text(
                            text = date,
                            fontSize = 15.sp
                        )
                    }

                    Spacer(
                        modifier =
                            Modifier.height(12.dp)
                    )

                    Row(
                        verticalAlignment =
                            Alignment.CenterVertically
                    ) {

                        Icon(
                            imageVector =
                                Icons.Default.Schedule,

                            contentDescription =
                                "Time",

                            tint =
                                Color(0xFF1976D2)
                        )

                        Spacer(
                            modifier =
                                Modifier.width(10.dp)
                        )

                        Text(
                            text = time,
                            fontSize = 15.sp
                        )
                    }

                    Spacer(
                        modifier =
                            Modifier.height(18.dp)
                    )

                    Text(
                        text = "Confirmed ✓",

                        color =
                            Color(0xFF2E7D32),

                        fontWeight =
                            FontWeight.Bold
                    )
                }
            }
        }
    }
}